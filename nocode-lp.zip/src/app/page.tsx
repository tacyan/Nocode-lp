/**
 * NoCode LPビルダーのメインページ
 * 
 * アプリケーションのメインページコンポーネント
 * ヘッダー、セクションリスト、エディタ、プレビューを配置
 * @module MainPage
 */

'use client';

import React, { useRef } from 'react';
import { Box, Grid, CssBaseline, ThemeProvider, createTheme } from '@mui/material';
import Header from './components/Header';
import SectionsList from './components/SectionsList';
import SectionEditor from './components/SectionEditor';
import Preview from './components/Preview';

// アプリケーションのテーマ設定
const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
  typography: {
    fontFamily: [
      '-apple-system',
      'BlinkMacSystemFont',
      '"Segoe UI"',
      'Roboto',
      '"Helvetica Neue"',
      'Arial',
      'sans-serif',
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(','),
  },
});

/**
 * メインページコンポーネント
 * 
 * @returns {JSX.Element} - メインページコンポーネント
 */
export default function Home() {
  // プレビュー要素への参照
  const previewRef = useRef<HTMLDivElement>(null);
  
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box sx={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
        <Header previewRef={previewRef} />
        
        <Box sx={{ flexGrow: 1, overflow: 'hidden', p: 2 }}>
          <Grid container spacing={2} sx={{ height: '100%' }}>
            {/* セクションリスト */}
            <Grid item xs={12} md={3} sx={{ height: '100%' }}>
              <SectionsList />
            </Grid>
            
            {/* セクション編集エリア */}
            <Grid item xs={12} md={4} sx={{ height: '100%' }}>
              <SectionEditor />
            </Grid>
            
            {/* プレビューエリア */}
            <Grid item xs={12} md={5} sx={{ height: '100%' }}>
              <Preview ref={previewRef} />
            </Grid>
          </Grid>
        </Box>
      </Box>
    </ThemeProvider>
  );
}
